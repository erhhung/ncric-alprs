--
-- PostgreSQL database dump
--

-- Dumped from database version 14.8 (Ubuntu 14.8-1.pgdg20.04+1)
-- Dumped by pg_dump version 14.8 (Ubuntu 14.8-1.pgdg20.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: org_1446ff84711242ec828df181f45e4d20; Type: DATABASE; Schema: -; Owner: atlas_user
--

CREATE DATABASE org_1446ff84711242ec828df181f45e4d20 WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'C.UTF-8';


ALTER DATABASE org_1446ff84711242ec828df181f45e4d20 OWNER TO atlas_user;

\connect org_1446ff84711242ec828df181f45e4d20

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: org_1446ff84711242ec828df181f45e4d20; Type: DATABASE PROPERTIES; Schema: -; Owner: atlas_user
--

ALTER DATABASE org_1446ff84711242ec828df181f45e4d20 SET search_path TO '$user', 'public', 'integrations';


\connect org_1446ff84711242ec828df181f45e4d20

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: integrations; Type: SCHEMA; Schema: -; Owner: atlas_user
--

CREATE SCHEMA integrations;


ALTER SCHEMA integrations OWNER TO atlas_user;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: standardized_agency_names; Type: TABLE; Schema: integrations; Owner: atlas_user
--

CREATE TABLE integrations.standardized_agency_names (
    "ol.name" text NOT NULL,
    standardized_agency_name text NOT NULL,
    "ol.datasource" text NOT NULL
);


ALTER TABLE integrations.standardized_agency_names OWNER TO atlas_user;

--
-- Data for Name: standardized_agency_names; Type: TABLE DATA; Schema: integrations; Owner: atlas_user
--

COPY integrations.standardized_agency_names ("ol.name", standardized_agency_name, "ol.datasource") FROM stdin;
American Canyon CA PD	American Canyon PD	FLOCK
Anderson City CA PD	Anderson City PD	FLOCK
ATHERTON	Atherton PD	BOSS4
ATHERTON POLICE DEPARTMENT	Atherton PD	BOSS4
Atherton	Atherton PD	BOSS4
Atherton CA PD	Atherton PD	FLOCK
Atherton PD	Atherton PD	BOSS4
Atherton PD	Atherton PD	FLOCK
BART	Bay Area Rapid Transit	BOSS4
BAY AREA RAPID TRANSIT	Bay Area Rapid Transit	BOSS4
Bay Area Rapid Transit	Bay Area Rapid Transit	BOSS4
BENICIA	Benicia PD	BOSS4
BENICIA POLICE DEPARTMENT	Benicia PD	BOSS4
Benicia	Benicia PD	BOSS4
Benicia CA PD	Benicia PD	FLOCK
Benicia PD	Benicia PD	BOSS4
Beverly Hills CA PD	Beverly Hills PD	FLOCK
BRISBANE	Brisbane PD	BOSS4
BRISBANE POLICE DEPARTMENT	Brisbane PD	BOSS4
Brisbane	Brisbane PD	BOSS4
Brisbane CA PD	Brisbane PD	FLOCK
Brisbane PD	Brisbane PD	BOSS4
Burlingame CA PD	Burlingame PD	FLOCK
CA HIGHWAY PATROL	CHP	BOSS4
CA Highway Patrol	CHP	BOSS4
CHP	CHP	BOSS4
CAMPBELL	Campbell PD	BOSS4
CAMPBELL POLICE DEPARTMENT	Campbell PD	BOSS4
Campbell	Campbell PD	BOSS4
Campbell CA PD	Campbell PD	FLOCK
Campbell PD	Campbell PD	BOSS4
CENTRAL MARIN	Central Marin PA	BOSS4
CENTRAL MARIN POLICE AUTHORITY	Central Marin PA	BOSS4
Central Marin	Central Marin PA	BOSS4
Central Marin Police Authority	Central Marin PA	BOSS4
CHICO	Chico PD	BOSS4
CHICO POLICE DEPARTMENT	Chico PD	BOSS4
Chico	Chico PD	BOSS4
Chico PD	Chico PD	BOSS4
Colma CA PD	Colma PD	FLOCK
Concord CA PD	Concord PD	FLOCK
Contra Costa CA SO Alamo P2	Contra Costa SO	FLOCK
Contra Costa CA SO Alamo P5	Contra Costa SO	FLOCK
Contra Costa SO Bay Point	Contra Costa SO	FLOCK
DALY CITY	Daly City PD	BOSS4
DALY CITY POLICE DEPARTMENT	Daly City PD	BOSS4
Daly City	Daly City PD	BOSS4
Daly City PD	Daly City PD	BOSS4
DANVILLE	Danville PD	BOSS4
DANVILLE POLICE DEPARTMENT	Danville PD	BOSS4
Danville	Danville PD	BOSS4
Danville CA PD	Danville PD	FLOCK
Danville PD	Danville PD	BOSS4
DIXON	Dixon PD	BOSS4
DIXON POLICE DEPARTMENT	Dixon PD	BOSS4
Dixon	Dixon PD	BOSS4
Dixon CA PD	Dixon PD	FLOCK
Dixon PD	Dixon PD	BOSS4
Fairfield CA PD	Fairfield PD	FLOCK
City of Fremont	Fremont PD	FLOCK
FREMONT	Fremont PD	BOSS4
FREMONT POLICE DEPARTMENT	Fremont PD	BOSS4
Fremont	Fremont PD	BOSS4
Fremont PD	Fremont PD	BOSS4
GGB VISTA POINT	GGB Vista Point	BOSS4
GGB VISTA POINT	GGB Vista Point	FLOCK
GGB Vista Point	GGB Vista Point	FLOCK
GGB Vista Point	GGB Vista Point	BOSS4
Gilroy CA PD	Gilroy PD	FLOCK
HIDTA	HIDTA	BOSS4
Hayward CA PD	Hayward PD	FLOCK
Hercules CA PD	Hercules PD	FLOCK
Hillsborough CA PD	Hillsborough PD	FLOCK
Hillsborough CA PD (Flex)	Hillsborough PD	FLOCK
Kaiser Permanente - Vallejo (CA)	Kaiser Permanente	FLOCK
La Habra CA PD	La Habra PD	FLOCK
Lakeport CA PD	Lakeport PD	FLOCK
LIVERMORE	Livermore PD	BOSS4
LIVERMORE POLICE DEPARTMENT	Livermore PD	BOSS4
Livermore	Livermore PD	BOSS4
Livermore CA PD	Livermore PD	FLOCK
Livermore PD	Livermore PD	BOSS4
Los Alamitos PD CA	Los Alamitos PD	FLOCK
LOS ALTOS	Los Altos PD	BOSS4
LOS ALTOS POLICE DEPARTMENT	Los Altos PD	BOSS4
Los Altos	Los Altos PD	BOSS4
Los Altos PD	Los Altos PD	BOSS4
Los Altos PD	Los Altos PD	SCSO
MANUAL ENTRIES	Manual Entries	BOSS4
Manual Entries	Manual Entries	BOSS4
MENLO PARK	Menlo Park PD	BOSS4
MENLO PARK POLICE DEPARTMENT	Menlo Park PD	BOSS4
Menlo Park	Menlo Park PD	BOSS4
Menlo Park PD	Menlo Park PD	BOSS4
City of Millbrae CA	Millbrae PD	FLOCK
Millbrae CA PD	Millbrae PD	FLOCK
Milpitas CA PD	Milpitas PD	FLOCK
MORGAN HILL	Morgan Hill PD	BOSS4
MORGAN HILL POLICE DEPARTMENT	Morgan Hill PD	BOSS4
Morgan Hill	Morgan Hill PD	BOSS4
Morgan Hill CA PD	Morgan Hill PD	FLOCK
Morgan Hill PD	Morgan Hill PD	BOSS4
NCRIC	NCRIC	BOSS4
NCRIC	NCRIC	FLOCK
NAPA	Napa PD	BOSS4
NAPA POLICE DEPARTMENT	Napa PD	BOSS4
Napa	Napa PD	BOSS4
Napa CA PD	Napa PD	FLOCK
Napa PD	Napa PD	FLOCK
Napa PD	Napa PD	BOSS4
NEWARK	Newark PD	BOSS4
NEWARK POLICE DEPARTMENT	Newark PD	BOSS4
Newark	Newark PD	BOSS4
Newark CA PD	Newark PD	FLOCK
Newark PD	Newark PD	BOSS4
Novato CA PD	Novato PD	FLOCK
Oakley CA PD	Oakley PD	FLOCK
Ontario CA PD	Ontario PD	FLOCK
Orinda CA PD	Orinda PD	FLOCK
PALO ALTO	Palo Alto PD	BOSS4
PALO ALTO POLICE DEPARTMENT	Palo Alto PD	BOSS4
Palo Alto	Palo Alto PD	BOSS4
Palo Alto PD	Palo Alto PD	BOSS4
PIEDMONT	Piedmont PD	BOSS4
PIEDMONT POLICE DEPARTMENT	Piedmont PD	BOSS4
Piedmont	Piedmont PD	BOSS4
Piedmont CA PD	Piedmont PD	FLOCK
Piedmont PD	Piedmont PD	BOSS4
Pleasanton CA PD	Pleasanton PD	FLOCK
Presidio Trust CA PD	Presidio Trust PD	FLOCK
The Presidio Trust CA PD	Presidio Trust PD	FLOCK
RIO VISTA	Rio Vista PD	BOSS4
RIO VISTA POLICE DEPARTMENT	Rio Vista PD	BOSS4
Rio Vista	Rio Vista PD	BOSS4
Rio Vista PD	Rio Vista PD	BOSS4
Salinas CA PD	Salinas PD	FLOCK
San Bruno CA PD	San Bruno PD	FLOCK
SAN FRANCISCO	San Francisco PD	BOSS4
SAN FRANCISCO POLICE DEPARTMENT	San Francisco PD	BOSS4
San Francisco	San Francisco PD	BOSS4
San Francisco PD	San Francisco PD	BOSS4
San Joaquin County CA SO	San Joaquin County SO	FLOCK
SAN LEANDRO	San Leandro PD	BOSS4
SAN LEANDRO POLICE DEPARTMENT	San Leandro PD	BOSS4
San Leandro	San Leandro PD	BOSS4
San Leandro PD	San Leandro PD	BOSS4
San Leandro PD CA	San Leandro PD	FLOCK
San Mateo County CA SO	San Mateo County SO	FLOCK
SAN MATEO	San Mateo PD	BOSS4
SAN MATEO	San Mateo PD	FLOCK
SAN MATEO POLICE DEPARTMENT	San Mateo PD	BOSS4
SAN MATEO POLICE DEPARTMENT	San Mateo PD	FLOCK
San Mateo	San Mateo PD	FLOCK
San Mateo	San Mateo PD	BOSS4
San Mateo CA PD	San Mateo PD	FLOCK
San Mateo PD	San Mateo PD	FLOCK
San Mateo PD	San Mateo PD	BOSS4
SAN MATEO VTTF	San Mateo VTTF	BOSS4
San Mateo VTTF	San Mateo VTTF	BOSS4
San Ramon CA PD	San Ramon PD	FLOCK
SANTA CLARA COUNTY SHERIFF'S OFFICE	Santa Clara County SO	BOSS4
SANTA CLARA COUNTY SHERIFFS OFFICE	Santa Clara County SO	BOSS4
Santa Clara County Sheriff's Office	Santa Clara County SO	BOSS4
Santa Clara County Sheriffs Office	Santa Clara County SO	BOSS4
SANTA CLARA	Santa Clara PD	BOSS4
SANTA CLARA POLICE DEPARTMENT	Santa Clara PD	BOSS4
Santa Clara	Santa Clara PD	BOSS4
Santa Clara CA PD	Santa Clara PD	FLOCK
Santa Clara PD	Santa Clara PD	BOSS4
Seal Beach CA PD	Seal Beach PD	FLOCK
SOLANO COUNTY	Solano County SO	BOSS4
SOLANO COUNTY SHERIFFS OFFICE	Solano County SO	BOSS4
Solano County	Solano County SO	BOSS4
Solano County Sheriffs Office	Solano County SO	BOSS4
SOUTH SAN FRANCISCO	South San Francisco PD	BOSS4
SOUTH SAN FRANCISCO POLICE DEPARTMENT	South San Francisco PD	BOSS4
South San Francisco	South San Francisco PD	BOSS4
South San Francisco PD	South San Francisco PD	BOSS4
SUISUN	Suisun PD	BOSS4
SUISUN POLICE DEPARTMENT	Suisun PD	BOSS4
Suisun	Suisun PD	BOSS4
Suisun PD	Suisun PD	BOSS4
SUNNYVALE DPS	Sunnyvale DPS	BOSS4
Sunnyvale DPS	Sunnyvale DPS	BOSS4
SUNNYVALE	Sunnyvale PD	BOSS4
SUNNYVALE POLICE DEPARTMENT	Sunnyvale PD	BOSS4
Sunnyvale	Sunnyvale PD	BOSS4
Sunnyvale PD	Sunnyvale PD	BOSS4
Tracy CA PD	Tracy PD	FLOCK
VACAVILLE	Vacaville PD	BOSS4
VACAVILLE POLICE DEPARTMENT	Vacaville PD	BOSS4
Vacaville	Vacaville PD	BOSS4
Vacaville CA PD	Vacaville PD	FLOCK
Vacaville PD	Vacaville PD	BOSS4
VALLEJO	Vallejo PD	BOSS4
VALLEJO POLICE DEPARTMENT	Vallejo PD	BOSS4
Vallejo	Vallejo PD	BOSS4
Vallejo CA PD	Vallejo PD	FLOCK
Vallejo CA PD (Flex)	Vallejo PD	FLOCK
Vallejo PD	Vallejo PD	FLOCK
Vallejo PD	Vallejo PD	BOSS4
YOSEMITE	Yosemite National Park	BOSS4
YOSEMITE NATIONAL PARK	Yosemite National Park	BOSS4
Yosemite	Yosemite National Park	BOSS4
Yosemite National Park	Yosemite National Park	BOSS4
\.


--
-- Name: standardized_agency_names agency_name_pkey; Type: CONSTRAINT; Schema: integrations; Owner: atlas_user
--

ALTER TABLE ONLY integrations.standardized_agency_names
    ADD CONSTRAINT agency_name_pkey PRIMARY KEY ("ol.name", "ol.datasource");


--
-- Name: standardized_agency_name_idx; Type: INDEX; Schema: integrations; Owner: atlas_user
--

CREATE INDEX standardized_agency_name_idx ON integrations.standardized_agency_names USING btree (standardized_agency_name);


--
-- Name: flock_reads_sun; Type: TABLE; Schema: integrations; Owner: atlas_user
--

CREATE TABLE integrations.flock_reads_sun (
    readid bigint NOT NULL,
    "timestamp" timestamp with time zone,
    type text,
    plate text,
    confidence real,
    latitude double precision,
    longitude double precision,
    cameraid bigint,
    cameraname text,
    platestate text,
    speed smallint,
    direction text,
    model text,
    hotlistid text,
    hotlistname text,
    cameralocationlat double precision,
    cameralocationlon double precision,
    cameranetworkid bigint,
    cameranetworkname text,
    image bytea,
    contextxcoordinate bigint,
    contextycoordinate bigint,
    contextheight bigint,
    contextwidth bigint
);


ALTER TABLE integrations.flock_reads_sun OWNER TO atlas_user;

--
-- Name: flock_reads_mon; Type: TABLE; Schema: integrations; Owner: atlas_user
--

CREATE TABLE integrations.flock_reads_mon (
    readid bigint NOT NULL,
    "timestamp" timestamp with time zone,
    type text,
    plate text,
    confidence real,
    latitude double precision,
    longitude double precision,
    cameraid bigint,
    cameraname text,
    platestate text,
    speed smallint,
    direction text,
    model text,
    hotlistid text,
    hotlistname text,
    cameralocationlat double precision,
    cameralocationlon double precision,
    cameranetworkid bigint,
    cameranetworkname text,
    image bytea,
    contextxcoordinate bigint,
    contextycoordinate bigint,
    contextheight bigint,
    contextwidth bigint
);


ALTER TABLE integrations.flock_reads_mon OWNER TO atlas_user;

--
-- Name: flock_reads_tue; Type: TABLE; Schema: integrations; Owner: atlas_user
--

CREATE TABLE integrations.flock_reads_tue (
    readid bigint NOT NULL,
    "timestamp" timestamp with time zone,
    type text,
    plate text,
    confidence real,
    latitude double precision,
    longitude double precision,
    cameraid bigint,
    cameraname text,
    platestate text,
    speed smallint,
    direction text,
    model text,
    hotlistid text,
    hotlistname text,
    cameralocationlat double precision,
    cameralocationlon double precision,
    cameranetworkid bigint,
    cameranetworkname text,
    image bytea,
    contextxcoordinate bigint,
    contextycoordinate bigint,
    contextheight bigint,
    contextwidth bigint
);


ALTER TABLE integrations.flock_reads_tue OWNER TO atlas_user;

--
-- Name: flock_reads_wed; Type: TABLE; Schema: integrations; Owner: atlas_user
--

CREATE TABLE integrations.flock_reads_wed (
    readid bigint NOT NULL,
    "timestamp" timestamp with time zone,
    type text,
    plate text,
    confidence real,
    latitude double precision,
    longitude double precision,
    cameraid bigint,
    cameraname text,
    platestate text,
    speed smallint,
    direction text,
    model text,
    hotlistid text,
    hotlistname text,
    cameralocationlat double precision,
    cameralocationlon double precision,
    cameranetworkid bigint,
    cameranetworkname text,
    image bytea,
    contextxcoordinate bigint,
    contextycoordinate bigint,
    contextheight bigint,
    contextwidth bigint
);


ALTER TABLE integrations.flock_reads_wed OWNER TO atlas_user;

--
-- Name: flock_reads_thu; Type: TABLE; Schema: integrations; Owner: atlas_user
--

CREATE TABLE integrations.flock_reads_thu (
    readid bigint NOT NULL,
    "timestamp" timestamp with time zone,
    type text,
    plate text,
    confidence real,
    latitude double precision,
    longitude double precision,
    cameraid bigint,
    cameraname text,
    platestate text,
    speed smallint,
    direction text,
    model text,
    hotlistid text,
    hotlistname text,
    cameralocationlat double precision,
    cameralocationlon double precision,
    cameranetworkid bigint,
    cameranetworkname text,
    image bytea,
    contextxcoordinate bigint,
    contextycoordinate bigint,
    contextheight bigint,
    contextwidth bigint
);


ALTER TABLE integrations.flock_reads_thu OWNER TO atlas_user;

--
-- Name: flock_reads_fri; Type: TABLE; Schema: integrations; Owner: atlas_user
--

CREATE TABLE integrations.flock_reads_fri (
    readid bigint NOT NULL,
    "timestamp" timestamp with time zone,
    type text,
    plate text,
    confidence real,
    latitude double precision,
    longitude double precision,
    cameraid bigint,
    cameraname text,
    platestate text,
    speed smallint,
    direction text,
    model text,
    hotlistid text,
    hotlistname text,
    cameralocationlat double precision,
    cameralocationlon double precision,
    cameranetworkid bigint,
    cameranetworkname text,
    image bytea,
    contextxcoordinate bigint,
    contextycoordinate bigint,
    contextheight bigint,
    contextwidth bigint
);


ALTER TABLE integrations.flock_reads_fri OWNER TO atlas_user;

--
-- Name: flock_reads_sat; Type: TABLE; Schema: integrations; Owner: atlas_user
--

CREATE TABLE integrations.flock_reads_sat (
    readid bigint NOT NULL,
    "timestamp" timestamp with time zone,
    type text,
    plate text,
    confidence real,
    latitude double precision,
    longitude double precision,
    cameraid bigint,
    cameraname text,
    platestate text,
    speed smallint,
    direction text,
    model text,
    hotlistid text,
    hotlistname text,
    cameralocationlat double precision,
    cameralocationlon double precision,
    cameranetworkid bigint,
    cameranetworkname text,
    image bytea,
    contextxcoordinate bigint,
    contextycoordinate bigint,
    contextheight bigint,
    contextwidth bigint
);


ALTER TABLE integrations.flock_reads_sat OWNER TO atlas_user;


--
-- Name: flock_reads_sun flock_reads_sun_pkey; Type: CONSTRAINT; Schema: integrations; Owner: atlas_user
--

ALTER TABLE ONLY integrations.flock_reads_sun
    ADD CONSTRAINT flock_reads_sun_pkey PRIMARY KEY (readid);


--
-- Name: flock_reads_sun_cameranetworkname_idx; Type: INDEX; Schema: integrations; Owner: atlas_user
--

CREATE INDEX flock_reads_sun_cameranetworkname_idx ON integrations.flock_reads_sun USING btree (cameranetworkname);


--
-- Name: flock_reads_sun_timestamp_idx; Type: INDEX; Schema: integrations; Owner: atlas_user
--

CREATE INDEX flock_reads_sun_timestamp_idx ON integrations.flock_reads_sun USING btree ("timestamp");


--
-- Name: flock_reads_mon flock_reads_mon_pkey; Type: CONSTRAINT; Schema: integrations; Owner: atlas_user
--

ALTER TABLE ONLY integrations.flock_reads_mon
    ADD CONSTRAINT flock_reads_mon_pkey PRIMARY KEY (readid);


--
-- Name: flock_reads_mon_cameranetworkname_idx; Type: INDEX; Schema: integrations; Owner: atlas_user
--

CREATE INDEX flock_reads_mon_cameranetworkname_idx ON integrations.flock_reads_mon USING btree (cameranetworkname);


--
-- Name: flock_reads_mon_timestamp_idx; Type: INDEX; Schema: integrations; Owner: atlas_user
--

CREATE INDEX flock_reads_mon_timestamp_idx ON integrations.flock_reads_mon USING btree ("timestamp");


--
-- Name: flock_reads_tue flock_reads_tue_pkey; Type: CONSTRAINT; Schema: integrations; Owner: atlas_user
--

ALTER TABLE ONLY integrations.flock_reads_tue
    ADD CONSTRAINT flock_reads_tue_pkey PRIMARY KEY (readid);


--
-- Name: flock_reads_tue_cameranetworkname_idx; Type: INDEX; Schema: integrations; Owner: atlas_user
--

CREATE INDEX flock_reads_tue_cameranetworkname_idx ON integrations.flock_reads_tue USING btree (cameranetworkname);


--
-- Name: flock_reads_tue_timestamp_idx; Type: INDEX; Schema: integrations; Owner: atlas_user
--

CREATE INDEX flock_reads_tue_timestamp_idx ON integrations.flock_reads_tue USING btree ("timestamp");


--
-- Name: flock_reads_wed flock_reads_wed_pkey; Type: CONSTRAINT; Schema: integrations; Owner: atlas_user
--

ALTER TABLE ONLY integrations.flock_reads_wed
    ADD CONSTRAINT flock_reads_wed_pkey PRIMARY KEY (readid);


--
-- Name: flock_reads_wed_cameranetworkname_idx; Type: INDEX; Schema: integrations; Owner: atlas_user
--

CREATE INDEX flock_reads_wed_cameranetworkname_idx ON integrations.flock_reads_wed USING btree (cameranetworkname);


--
-- Name: flock_reads_wed_timestamp_idx; Type: INDEX; Schema: integrations; Owner: atlas_user
--

CREATE INDEX flock_reads_wed_timestamp_idx ON integrations.flock_reads_wed USING btree ("timestamp");


--
-- Name: flock_reads_thu flock_reads_thu_pkey; Type: CONSTRAINT; Schema: integrations; Owner: atlas_user
--

ALTER TABLE ONLY integrations.flock_reads_thu
    ADD CONSTRAINT flock_reads_thu_pkey PRIMARY KEY (readid);


--
-- Name: flock_reads_thu_cameranetworkname_idx; Type: INDEX; Schema: integrations; Owner: atlas_user
--

CREATE INDEX flock_reads_thu_cameranetworkname_idx ON integrations.flock_reads_thu USING btree (cameranetworkname);


--
-- Name: flock_reads_thu_timestamp_idx; Type: INDEX; Schema: integrations; Owner: atlas_user
--

CREATE INDEX flock_reads_thu_timestamp_idx ON integrations.flock_reads_thu USING btree ("timestamp");


--
-- Name: flock_reads_fri flock_reads_fri_pkey; Type: CONSTRAINT; Schema: integrations; Owner: atlas_user
--

ALTER TABLE ONLY integrations.flock_reads_fri
    ADD CONSTRAINT flock_reads_fri_pkey PRIMARY KEY (readid);


--
-- Name: flock_reads_fri_cameranetworkname_idx; Type: INDEX; Schema: integrations; Owner: atlas_user
--

CREATE INDEX flock_reads_fri_cameranetworkname_idx ON integrations.flock_reads_fri USING btree (cameranetworkname);


--
-- Name: flock_reads_fri_timestamp_idx; Type: INDEX; Schema: integrations; Owner: atlas_user
--

CREATE INDEX flock_reads_fri_timestamp_idx ON integrations.flock_reads_fri USING btree ("timestamp");


--
-- Name: flock_reads_sat flock_reads_sat_pkey; Type: CONSTRAINT; Schema: integrations; Owner: atlas_user
--

ALTER TABLE ONLY integrations.flock_reads_sat
    ADD CONSTRAINT flock_reads_sat_pkey PRIMARY KEY (readid);


--
-- Name: flock_reads_sat_cameranetworkname_idx; Type: INDEX; Schema: integrations; Owner: atlas_user
--

CREATE INDEX flock_reads_sat_cameranetworkname_idx ON integrations.flock_reads_sat USING btree (cameranetworkname);


--
-- Name: flock_reads_sat_timestamp_idx; Type: INDEX; Schema: integrations; Owner: atlas_user
--

CREATE INDEX flock_reads_sat_timestamp_idx ON integrations.flock_reads_sat USING btree ("timestamp");


--
-- PostgreSQL database dump complete
--

